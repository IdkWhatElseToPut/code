public class RunnerA {
    public static void main(String[] args){
        Quiz5 q5 =  new Quiz5();
        q5.countDownBy3(15);
        System.out.println("\n");
        System.out.println(q5.getSummation(6));
    }
}
